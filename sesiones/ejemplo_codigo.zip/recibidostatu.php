<?php 
session_start();

	if (isset($_POST['x'])) {
	
	session_unset();
	session_destroy();
	echo "El estado de su session es: ";
	print_r(session_status());
	echo " Que significa que su session fue vaciada y ya no existe";
	}
 ?>