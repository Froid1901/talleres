<?php
session_start();
$_SESSION['nombre'] = $_POST['nombre'];

session_name($_SESSION['nombre']);

echo "Este es su nombre de session: <br>".session_name();


?>