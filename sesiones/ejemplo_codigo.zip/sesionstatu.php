
 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 </head>
 <body>
 
<?php 
	
	if ($_POST['nombre']=="") 	
		header("location:index.php");
	else		
		session_start();
		session_name($_POST['nombre']);		
		echo "Bienvenido: ".session_name()." su sesion fue creada";
echo "<br>";
		echo "el estado de su sesion es: ";
 		print_r(session_status());
 		echo " que significa que su sesion si existe y esta activa";
echo "<br>";
  ?>
 <form action="recibidostatu.php" method="POST">
 	<input type="submit" value="Eliminar" name="x">
 </form>
  
  
 </body>
 </html>