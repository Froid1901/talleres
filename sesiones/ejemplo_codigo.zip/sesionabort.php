<?php
session_start();
$_SESSION['numero'] = $_POST['numero'];

if(isset($_SESSION['numero'])){
    $_SESSION['numero']++;
}else{
    $_SESSION['numero'] = 1;
}
echo "El incremento de un numero que dijitamos en este caso: ".$_POST['numero']." |
este es el resultado despues de ejecutar dicha operacion: ".$_SESSION['numero'];
echo "<br>";
echo session_status()." Este es el estado actual antes de usar session_abort que significa que la session existe";
echo "<br>";
echo "Despues de este texto usamos el session_abort: ".session_abort();
echo "<br>";
echo "Como podemos ver no arroja ningun valor";
echo "<br>";
echo "Aqui usaremos un amigo session_status para verificar el estado de la session que es igual a: ";
echo session_status()." que significa que la session fue finalizada o no existe";

?>