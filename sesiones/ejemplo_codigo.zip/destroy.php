
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
<?php
error_reporting(0);
session_start();
$_SESSION['nombre'] = $_POST['nombre'];
echo "Bienvenido culer@ ".$_SESSION['nombre'];

//Al usar el boton se cierra la sesion
 if ($_POST['CerrarSesion']) 
{
session_destroy();

    //Y redirecciona
    header("Location:index.php"); 
}


//Formulario con el boton
?>

<form method="POST">

<input type="submit" name="CerrarSesion" value="Cerrar Sesion">
<form>
</body>
</html>
