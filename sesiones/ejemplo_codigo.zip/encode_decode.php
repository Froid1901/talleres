<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
<?php

session_start(); 
$_SESSION['nombre'] = $_POST['nombre'];
$_SESSION['contra'] = $_POST['contra'];


$codificado = session_encode();

echo "su mensaje codificado es: <br>".$codificado."<hr>";

$_SESSION=array();

session_decode($codificado);

echo "su mensaje decodificado es: <br>";
print_r($_SESSION);


 ?>
</body>
</html>