<?php 
	
	if ($_POST['nombre']=="") 	
		header("location:index.php");
	else		
		session_start();
		session_name($_POST['nombre']);
		
		echo "Bienvenido: ".session_name()." su sesion fue iniciada";
	

 ?>