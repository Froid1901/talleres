<?php
$_SESSION['nombre'] = $_POST['nombre'];
$_SESSION['contra'] = $_POST['contra'];
//$a = session_id();
//if(empty($a)) 
if (isset($_SESSION['nombre'])) {
session_start();
echo "Su numero de session es: <br>".session_id();	
}


?>