<?php 
if (isset($_POST['nombre'])) {
session_start();	
$lol=session_cache_expire();
echo "---------------------------------------------------------------------------------------------------------------------";
echo "<br>";
echo "El limite de tiempo que se guardara el cache de la session es: ".$lol." este tiempo se mide en minutos";
echo "<br>";
echo "---------------------------------------------------------------------------------------------------------------------";
}
 ?>