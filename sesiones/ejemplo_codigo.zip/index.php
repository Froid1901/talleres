<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>
		
	</title>


</head>
<body>

	<h1>Ingrese un numero</h1>

 <form method="POST" action="sesion.php" >
 <strong>Nombre: </strong>
<br>
 <input type="text" name="nombre" placeholder="user" >
 <br>
 <br>
 <strong>Escriba contraseña: </strong>
 <br>
 <input type="password" name="contra"  placeholder="contra">
 <br>
 <br><input type="submit" value="ENVIAR">
 </form>

</body>
</html>


