<?php
    session_start();
    $_SESSION['nombre'] = $_POST['nombre'];
    $_SESSION['contra'] = $_POST['contra'];

echo "Este es el contenido de su array: <br>";
    print_r($_SESSION);

echo "<hr>";

echo "Lo siguiente es cuando actua el session_reset: <br>";

    session_reset($_SESSION);  

    print_r($_SESSION);

?>
