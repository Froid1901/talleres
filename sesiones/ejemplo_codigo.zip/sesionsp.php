<?php
session_start ();
echo "Ruta de guardado de sesión es: ", session_save_path ();
?>